"""Top-level package for shapFlex."""

__author__ = """Gregory Ch"""
__email__ = 'cubekot@gmail.com'
__version__ = '0.0.1'
